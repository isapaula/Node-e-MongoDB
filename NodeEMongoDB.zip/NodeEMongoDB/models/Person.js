const mongoose = require('mongoose')

const Pessoas = mongoose.model('Pessoas', {
    name: String,
    idade: Number,
    salario: Number,
    approved: Boolean
})

module.exports  = Pessoas