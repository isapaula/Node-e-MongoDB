const router = require('express').Router()

const req = require('express/lib/request')
const Pessoas =  require('../models/Person')

// create 
router.post('/', async(req, res) => {
    
    // req.body

    const {name, idade, salario, approved} = req.body

    if (!name) {
        res.status(422).json({ erro: "o nome é obrigatorio"})
        return
    }
    const pessoa = {
        name,
        idade, 
        salario,
        approved
    }
    // create mongoose 
    try {
        await Pessoas.create(pessoa)
        res.status(201).json({message: "Cadastro efetuado com sucesso!"})
    } catch (error) {
        res.status(500).json({error: error})
        
    }
})
// read 

router.get('/', async(req, res) => {

    try {
        
        const pessoas = await Pessoas.find()

        res.status(200).json(pessoas)

    } catch (error) {
        res.status(500).json({error: error})
    }


})

// pegar um registro pelo id

router.get('/:id', async(req, res) =>{
    
    // nao usa o req.body usa se o req.params id
    const id = req.params.id

    try {

        const person = await Pessoas.findOne({_id: id})

        if (!person) {
            res.status(422).json({message: "pessoa nao encontrada"})
            return
        }

        res.status(200).json(person)
        
    } catch (error) {
        res.status(500).json({error: error})
    }
})

// editar -> PUT e PATCH 

router.patch('/:id', async(req, res) => {

    const id = req.params.id

    const {name, idade, salario, approved} = req.body

    const person = {
        name,
        idade,
        salario,
        approved
    }

    try {
        
        const updatePerson = await Pessoas.updateOne({_id: id}, person)

        if (updatePerson.matchedCount === 0) {
            res.status(422).json({message: "pessoa nao encontrada"})
            return
        }

        res.status(200).json(person)
    } catch (error) {
        res.status(500).json({error: error})
    }
})

// delete

router.delete('/:id', async(req, res) => {

    const id = req.params.id

    const person = await Pessoas.findOne({_id: id})

    if (!person) {
        res.status(422).json({message: "pessoa nao encontrada"})
        return
    }

    try {
        await Pessoas.deleteOne({_id: id})

        res.status(200).json({message: "excluido com sucesso!"})
    } catch (error) {
        res.status(500).json({error: error})
    }

})


module.exports = router