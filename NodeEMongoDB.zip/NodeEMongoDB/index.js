// config inicial
require('dotenv').config() 
const express = require('express')
const mongoose = require('mongoose')
const app = express()

// form de ler json
app.use(
    express.urlencoded({
        extended: true
    })
)
// comando responsavel por enviar e mandar json 
app.use(express.json())

const routerPerson = require('./routes/RouterPerson')

app.use('/person', routerPerson)

// rotas ada api 
// o async tem o objetivo de esperar um tempo antes de 
// dar uma resposta ao usuario 
// acho que seria uma funçao sem retorno
app.get('/', (req, res) => {
    res.send('Funcionado')
})

const DB_USER = process.env.DB_USER
const DB_PASSWORD = encodeURIComponent(process.env.DB_PASSWORD)

mongoose.connect(`mongodb+srv://${DB_USER}:${DB_PASSWORD}@cluster0.n1xbl.mongodb.net/dbNodeApi?retryWrites=true&w=majority`).then( () => {
    console.log('conectado com sucesso')
}).catch((err) => console.log('Nao conectou com banco'+err))

app.listen(3300, function () {
    console.log('esta na porta 3300')
})
